package com.central.zepto.central_api.enums;

public enum UserType {
    APPLICATION_ADMIN,
    WAREHOUSE_ADMIN,
    CUSTOMER,
    DELIVERY_PARTNER
}
