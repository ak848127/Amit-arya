package com.central.zepto.central_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentralApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
