package com.db.zepto.db_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
