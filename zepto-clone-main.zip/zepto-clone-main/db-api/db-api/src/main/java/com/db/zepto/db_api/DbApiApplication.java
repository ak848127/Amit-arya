package com.db.zepto.db_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbApiApplication.class, args);
	}

}
